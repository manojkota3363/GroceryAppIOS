//
//  GrocerySections.swift
//  kota_GroceryApp
//
//  Created by kota,Manoj on 4/5/22.
//

import Foundation
import UIKit

struct GroceryItem {
    var itemName: [String]
}

struct GrocerySections  {
    var section: [String]
    var itemImage: [String]
}
