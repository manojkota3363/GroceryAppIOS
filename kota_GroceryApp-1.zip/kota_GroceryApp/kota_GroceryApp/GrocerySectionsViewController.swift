//
//  GrocerySectionsViewController.swift
//  kota_GroceryApp
//
//  Created by kota,Manoj on 4/5/22.
//

import UIKit

var itemslist = [String]()

var itemsdisplay = [GroceryItem]()

var imagearray = [GrocerySections ]()

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "GrocerySections"
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
        
        //Arrays
        itemslist = [
                    
                    "Meat and seafood",
                    "pantry",
                    "Bevarges",
                    "Frozen",
                    "Fresh Food"
                    
                ]
                
                itemsdisplay = [
                    
                    GroceryItem(itemName: ["Beef &Lamb","Chicken","Turkey","Pork","prawns"]),
                    GroceryItem(itemName: ["Boxes of pasta","Tomato sause","Rice","Oat Meal","Mixed Nuts"]),
                    GroceryItem(itemName: ["Milk","tea","coffe","Juice","Enery Drink"]),
                    GroceryItem(itemName: ["Ice Creams","Plaimn chicken","Honeymoon ice cream","chapathis","Fish fillets"]),
                    GroceryItem(itemName: ["Sambar","dhal","fish Fry","fruits","chicken chaloopa"])
                    
                ]
                
                imagearray = [
                    
                    GrocerySections (
                    section: ["beef","chicken","turkey","porki","prawnsp"],
                    itemImage: [
                        "beef, flesh of mature cattle, as distinguished from veal, the flesh of calves. The best beef is obtained from early maturing, special beef breeds.",
                        "A chicken is a bird. One of the features that differentiate it from most other birds is that it has a comb and two wattles.",
                        "Turkeys are dark overall with a bronze-green iridescence to most of their plumage. Their wings are dark, boldly barred with white.",
                        "pork, flesh of hogs, usually slaughtered between the ages of six months and one year. The most desirable pork is grayish pink in colour, firm and fine-grained, well-marbled, and covered with an outer layer of firm white fat.",
                        "A prawn is a crustacean that resembles a big shrimp, with long antennae and a shell. When you see prawns on a menu, just imagine large, juicy shrimp."]),
                    
                    GrocerySections (
                    section: ["pastap","sausagep","ricep","oatmeatp","mixednutspics"],
                    itemImage: [
                        "Pasta is a type of food made from a mixture of flour, eggs, and water that is formed into different shapes and then boiled. Spaghetti, macaroni, and noodles are types of pasta.",
                        "sausage, meat product made of finely chopped and seasoned meat, which may be fresh, smoked, or pickled and which is then usually stuffed into a casing",
                        "rice, (Oryza sativa), edible starchy cereal grain and the grass plant (family Poaceae) by which it is produced",
                        "Oatmeal is a breakfast food made from oats and liquid like water or milk",
                        
                        "Mixed nuts are a snack food consisting of any mixture of mechanically or manually combined nuts."]),
                    
                    GrocerySections (
                    section: ["milkp","teap","coffep","juicep","enerydrinkp"],
                    itemImage: [
                        "Milk is essentially an emulsion of fat and protein in water, along with dissolved sugar (carbohydrate), minerals, and vitamins.",
                        "Tea is an aromatic beverage prepared by pouring hot or boiling water over cured or fresh leaves of Camellia sinensis, an evergreen shrub native to China, India and other East Asian countries.",
                        "Coffee is darkly colored, bitter, slightly acidic and has a stimulating effect in humans, primarily due to its caffeine content.",
                        "Juice is a drink made from the extraction or pressing of the natural liquid contained in fruit and vegetables.",
                        "A beverage that typically contains large amounts of caffeine, added sugars, other additives, and legal stimulants such as guarana, taurine, and L-carnitine."]),
                    
                    GrocerySections (
                    section: ["Ice Creamp","plainchickenp","Honeymoonp","chapathisp","FishFilletsp"],
                    itemImage: [
                        "Ice cream is a mixture of milk, cream, sugar, and sometimes other ingredients that has been frozen into a soft, creamy delight using special techniques.",
                        "Chicken can be cooked in many ways. It can be made into sausages, skewered, put in salads, traditionally grilled or by using electric grill, breaded and deep-fried, or used in various curries.",
                        "Northern California Ice Cream Manufacturer known for unique Ice Cream flavors made with Jersey Milk.",
                        "a round flat unleavened bread of India that is usually made of whole wheat flour and cooked on a griddle.",
                        "A fish fillet, from the French word filet (pronounced [filɛ]) meaning a thread or strip, is the flesh of a fish which has been cut"]),
                    
                    GrocerySections (
                    section: ["Sambarp","dhalp","Fishfryp","fruitsp","chaloopap"],
                    itemImage: [
                        "Sambar is a South Indian lentil and vegetable stew made with pigeon pea lentils, tamarind and a unique spice blend called sambar powder. ",
                        "Dal or dhal, just like posole (or pozole) is both an ingredient and a dish: it refers to a type of dried split pea or lentil and the deeply spiced stew made from simmering the split peas until nicely broken down.",
                        "A fish fry is a meal containing battered or breaded fried fish.",
                        "In a botanical sense, a fruit is the fleshy or dry ripened ovary of a flowering plant, enclosing the seed or seeds.",
                        "A chalupa is a specialty dish of south-central Mexico. Traditional chalupas are small, thick, boat-shaped fried dough topped only with Salsa, cheese, and shredded lettuce."])
                ]
            }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemslist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = itemslist[indexPath.row]
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = self.grocerySectionsTableView.indexPathForSelectedRow
        var itemsarray : GroceryItem
        var displayimage : GrocerySections 
        var description : GrocerySections 
        
        itemsarray = itemsdisplay[indexPath!.row]
        displayimage = imagearray[indexPath!.row]
        description = imagearray[indexPath!.row]
        
        let identifier = segue.identifier
        if identifier == "itemsSegue" {
            let destination = segue.destination as! GroceryItemsViewController
            destination.productarray = itemsarray.itemName
            destination.infoarray = description.itemImage
            destination.imagearray = displayimage.section
            destination.title = itemslist[indexPath!.row]
        }
    }
    
    }

    



