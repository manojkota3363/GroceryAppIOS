//
//  ItemInfoViewController.swift
//  kota_GroceryApp
//
//  Created by kota,Manoj on 4/5/22.
//

import UIKit

class ItemInfoViewController: UIViewController {
    
    var image = UIImage()
    var productInfo = String()

    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    @IBOutlet weak var itemInfoOutlet: UITextView!
    
    //@IBOutlet weak var itemInfoOutlet: UILabel!
    @IBOutlet weak var getInfoOutlet: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        getInfoOutlet.layer.cornerRadius = 15
        getInfoOutlet.clipsToBounds = true
        
        itemImageViewOutlet.image = image
        itemImageViewOutlet.layer.cornerRadius = 20
        itemImageViewOutlet.clipsToBounds = true
        
        
        itemInfoOutlet.text = ""
        
    }
    

    @IBAction func showItemInfoAction(_ sender: UIButton) {
        itemInfoOutlet.text = productInfo
        itemInfoOutlet.textColor = .darkText
        
    }
    

}
